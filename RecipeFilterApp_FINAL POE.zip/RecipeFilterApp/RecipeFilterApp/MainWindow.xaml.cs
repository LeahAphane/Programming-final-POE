﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using LiveCharts;
using LiveCharts.Wpf;
using System.Collections.ObjectModel;

namespace RecipeFilterApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Recipe> Recipes { get; set; } = new ObservableCollection<Recipe>();
        private ObservableCollection<IngredientDetail> CurrentIngredients { get; set; } = new ObservableCollection<IngredientDetail>();

        public MainWindow()
        {
            InitializeComponent();
            RecipeListView.ItemsSource = Recipes;
            IngredientListView.ItemsSource = CurrentIngredients;
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            var ingredientName = IngredientTextBox.Text;
            var foodGroup = ((ComboBoxItem)FoodGroupComboBox.SelectedItem).Content.ToString();
            if (int.TryParse(CaloriesTextBox.Text, out int calories))
            {
                CurrentIngredients.Add(new IngredientDetail { Name = ingredientName, FoodGroup = foodGroup, Calories = calories });
                IngredientTextBox.Clear();
                CaloriesTextBox.Clear();
            }
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            var recipeName = RecipeNameTextBox.Text;
            if (!string.IsNullOrWhiteSpace(recipeName))
            {
                var totalCalories = CurrentIngredients.Sum(i => i.Calories);
                var newRecipe = new Recipe { Name = recipeName, TotalCalories = totalCalories, Ingredients = new List<IngredientDetail>(CurrentIngredients) };
                Recipes.Add(newRecipe);
                Recipes = new ObservableCollection<Recipe>(Recipes.OrderBy(r => r.Name)); // Sort alphabetically
                RecipeListView.ItemsSource = Recipes; // Refresh the ListView
                CurrentIngredients.Clear();
                RecipeNameTextBox.Clear();
            }
        }

        private void DeleteRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Get selected recipes from the ListView
            var selectedRecipes = RecipeListView.SelectedItems.Cast<Recipe>().ToList();

            // Remove selected recipes from the collection
            foreach (var recipe in selectedRecipes)
            {
                Recipes.Remove(recipe);
            }
        }

        private void EditRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Get selected recipe from the ListView
            Recipe selectedRecipe = RecipeListView.SelectedItem as Recipe;

            if (selectedRecipe != null)
            {
                // Open a dialog or navigate to a new page to edit the selected recipe
                // Example: EditRecipeDialog dialog = new EditRecipeDialog(selectedRecipe);
                // dialog.ShowDialog();

                // After editing, update the recipe in the collection
                // Example: selectedRecipe.Name = dialog.NewName;
            }
        }

        private void RecipeListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRecipes = RecipeListView.SelectedItems.Cast<Recipe>().ToList();
            if (selectedRecipes.Any())
            {
                var selectedRecipe = selectedRecipes.First();
                IngredientListView.ItemsSource = selectedRecipe.Ingredients;
                TotalCaloriesTextBlock.Text = $"Total Calories: {selectedRecipe.TotalCalories}";
                if (selectedRecipe.TotalCalories > 300)
                {
                    MessageBox.Show("Warning: Total calories exceed 300!");
                }
                UpdatePieChart(selectedRecipes);
            }
        }

        private void ScaleRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItems.Count == 1 && double.TryParse(ScalingFactorTextBox.Text, out double factor))
            {
                var selectedRecipe = (Recipe)RecipeListView.SelectedItem;
                foreach (var ingredient in selectedRecipe.Ingredients)
                {
                    ingredient.Calories = (int)(ingredient.Calories * factor);
                }
                selectedRecipe.TotalCalories = selectedRecipe.Ingredients.Sum(i => i.Calories);
                IngredientListView.ItemsSource = selectedRecipe.Ingredients.ToList(); // Refresh the ListView
                TotalCaloriesTextBlock.Text = $"Total Calories: {selectedRecipe.TotalCalories}";
                UpdatePieChart(new List<Recipe> { selectedRecipe });
            }
        }

        private void ResetScaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItems.Count == 1)
            {
                var selectedRecipe = (Recipe)RecipeListView.SelectedItem;
                foreach (var ingredient in selectedRecipe.Ingredients)
                {
                    ingredient.Calories = ingredient.OriginalCalories; // Reset to original
                }
                selectedRecipe.TotalCalories = selectedRecipe.Ingredients.Sum(i => i.Calories);
                IngredientListView.ItemsSource = selectedRecipe.Ingredients.ToList(); // Refresh the ListView
                TotalCaloriesTextBlock.Text = $"Total Calories: {selectedRecipe.TotalCalories}";
                UpdatePieChart(new List<Recipe> { selectedRecipe });
            }
        }

        private void UpdatePieChart(List<Recipe> selectedRecipes)
        {
            PieChart.Series.Clear();
            var foodGroupCounts = new Dictionary<string, double>();

            foreach (var recipe in selectedRecipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (!foodGroupCounts.ContainsKey(ingredient.FoodGroup))
                    {
                        foodGroupCounts[ingredient.FoodGroup] = 0;
                    }
                    foodGroupCounts[ingredient.FoodGroup] += ingredient.Calories;
                }
            }

            foreach (var foodGroup in foodGroupCounts)
            {
                PieChart.Series.Add(new PieSeries
                {
                    Title = foodGroup.Key,
                    Values = new ChartValues<double> { foodGroup.Value }
                });
            }
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public int TotalCalories { get; set; }
        public List<IngredientDetail> Ingredients { get; set; }
    }

    public class IngredientDetail
    {
        public string Name { get; set; }
        public string FoodGroup { get; set; }
        public int Calories { get; set; }
        public int OriginalCalories { get; set; } // For resetting
    }
}